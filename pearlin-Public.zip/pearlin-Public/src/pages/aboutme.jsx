import React from 'react';

const About = () => {
  return (
    <div
      style={{
        justifyContent: 'center',
        alignItems: 'center'
      }}
    >
     <section>
  <h2>Introduction</h2>
    <p>Iam R Pearlin Rishwanth Iam a Full-Stack Web Developer experienced in ReactJs and AWS.</p>
</section>
<section>
  <h2>Languages Known</h2>
    <ul class="space-maker">
        <li>Tamil</li>
        <li>English</li>
    </ul>
</section>
<section>
  <h2>Programming Languages Known</h2>
    <ul class="space-maker">
        <li>C Language</li>
        <li>Python</li>
        <li>HTML</li>
        <li>CSS</li>
        <li>JAVA SCRIPT</li>
        <li>PHP (Beginner)</li>
        <li>ReactJS</li>
        <li>React Native</li>
        <li>AWS</li>
        <li>MySql</li>
    </ul>
</section>

<section>
  <h2>Personal Profile</h2>
    <ul class="space-maker">
        <li>Date of Birth : 11-01-1998</li>
        <li>Hobbies : Reading Books, Playing Music.</li>
    </ul>
</section>

<section>
  <h2>Indusrial Exposure</h2>
    <ul class="space-maker">
        <li>Completed a certified course on Front-End Web Development at Orange Technology an 
ISO Certified Academy Chennai.
</li>
        <li>Participated in Workshop on Internet - Of – Things (IoT) at Meenakshi College of 
Engineering Conducted by Pantech, Chennai.</li>
        <li>Participated in Workshop on Hacking and Game Development conducted by WikiTechy, 
Chennai
</li>
        <li>Participated in Workshop on Photo editing Software with OPEN CV on Python conducted 
by Omega Technologies Chennai.</li>
        
    </ul>
</section>






    </div>
  );
};

export default About;