import React from 'react';

const projects = () => {
  return (
    <div
      style={{
        justifyContent: 'center',
        alignItems: 'center'
      }}
    >
    

    <section>
  <h2>Projects</h2>
    <ul class="space-maker">
        <li><strong>DAILY EXPENSE AND INCOME MANAGEMENT SYSTEM</strong> using HTML, CSS, JS, PHP, MYSQL.

</li>
        <li><strong>TIRUNELVELI SMART CITY PROJECTS WEBPAGE</strong> using HTML, CSS, JS, PHP, MYSQL.
</li>
<li><strong>THIS WEBSITE</strong> Done Using Reactjs.

</li> 
        
    </ul>
</section>

    </div>
  );
};

export default projects;