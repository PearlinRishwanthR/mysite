import React from 'react';

const work = () => {
  return (
    <div
      style={{
        justifyContent: 'center',
        alignItems: 'center'
      }}
    >
    

    <section>
  <h2>Experience</h2>
  <h3>Work Experiece</h3>
  <p class="space-maker">Currently Iam working as a Associate Developer at <strong><a href="https://www.xbi4.com/" target="1" style={{color:'red'}}>XBI4</a></strong> located at Panpozhi near Tenkasi</p>
</section>

    </div>
  );
};

export default work;