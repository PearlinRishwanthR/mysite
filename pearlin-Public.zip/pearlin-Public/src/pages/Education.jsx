import React from 'react';

const About = () => {
  return (
    <div
      style={{
        justifyContent: 'center',
        alignItems: 'center'
      }}
    >
    

<section>
  <h2>Education</h2>
  <h3>First College</h3>
  <p class="space-maker">Started My Bachlore of engineering in Computer Science and Engineering at <strong><a href="https://mce.edu.in/" target="1" style={{color:'red'}}>Meenakshi College of Engineering Located at Chennai,Tamilnadu</a> </strong>joined at the year 2016 and Completed at the year 2018</p>
  <h3>Second College</h3>
  <p class="space-maker">Completed My Bachlore of engineering in Computer Science and Engineering at <strong><a href="http://scadengineering.ac.in/" target="1" style={{color:'red'}}>Scad College Of Engineering and Technology Located at Cheranmahadevi,Tamilnadu</a></strong> joined at the year 2019 and Completed at the year 2021</p>
<h3>HSC School</h3>
  <p class="space-maker">Completed My HSC at St.Johns Matriculaion and Higher Secondary School Located at Chennai, Tamilnadu in the Year <strong>2016</strong></p>
  <h3>SSLC School</h3>
  <p class="space-maker">Completed My SSLC at Good Shepherd Matriculation School Located at Chennai, Tamilnadu in the Year <strong>2014</strong></p>
</section>


    </div>
  );
};

export default About;