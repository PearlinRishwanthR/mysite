import React from 'react';
import {
  Nav,
  NavLink,
  Bars,
  NavMenu
} from './NavbarElements.jsx';
import {FcHome} from 'react-icons/fc'

const Navbar = () => {
  return (
    <>
      <Nav>
      
        <Bars />
        <NavMenu>
        <NavLink to='/' activeStyle>
        <FcHome/>
          </NavLink>
          <NavLink to='/about' activeStyle>
            About Me
          </NavLink>
          <NavLink to='/education' activeStyle>
           Education
          </NavLink>
          <NavLink to='/projects' activeStyle>
           Projects
          </NavLink>
          <NavLink to='/work' activeStyle>
           Work Experience
          </NavLink>
          <NavLink to='/resume' activeStyle>
           Resume
          </NavLink>
          
          {/* Second Nav */}
          {/* <NavBtnLink to='/sign-in'>Sign In</NavBtnLink> */}
        </NavMenu>
    
      </Nav>
    </>
  );
};

export default Navbar;